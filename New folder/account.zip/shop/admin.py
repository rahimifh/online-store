from django.contrib import admin
from .models import Category, Product,Comment,Brand,Adv
@admin.register(Brand)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']
    prepopulated_fields = {'slug': ('name',)}
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug', 'price','available', 'created', 'updated']
    list_filter = ['available', 'created', 'updated']
    list_editable = ['price', 'available']
    prepopulated_fields = {'slug': ('name',)}

@admin.register(Comment)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name','active', 'email', 'body']
    list_filter = ['created','active']
@admin.register(Adv)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name','created']
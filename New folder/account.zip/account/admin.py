from django.contrib import admin
#****003
from .models import Profile

#****003
@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'date_of_birth', 'photo']

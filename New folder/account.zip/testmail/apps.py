from django.apps import AppConfig


class TestmailConfig(AppConfig):
    name = 'testmail'

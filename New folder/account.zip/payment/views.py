from requests import Session
from zeep import Client, Transport
from orders.models import Order
from django.shortcuts import render
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
class PaymentGatewayAdapter(object):
    def __init__(self):
        pass

    def create_client(self, web_service) -> Client:
        session = Session()
        #session.headers = {}
        transport = Transport(session=session)
        #transport.session.headers = {}  # DON'T REMOVE THIS LINE.YOU BLOCK FROM SAMAN BANK IF REMOVE THIS LINE
        return Client(web_service, transport=transport)

    def sep_request_token(self, amount,res_num, additional_data: ['', '']):
        client = self.create_client('https://sep.shaparak.ir/payments/initpayment.asmx?wsdl')
        #res_num = self.sep_generate_reservation_number()
        response = client.service.RequestToken(
            '41139909171298831',
            res_num,
            amount,
            '0', '0', '0', '0', '0', '0',
            "0",
            "0",
            '0',
            'http://dobicho.com/payment/process/'
        )
        token = str(response)
        return token, res_num

    def sep_verify_transaction(self, ref_num):
        client = self.create_client('https://sep.shaparak.ir/payments/referencepayment.asmx?wsdl')
        result = client.service.verifyTransaction(
            ref_num,
            'saman mid'
        )
        return result

    def sep_reverse_transaction(self, ref_num):
        client = self.create_client('https://sep.shaparak.ir/payments/referencepayment.asmx?wsdl')
        result = client.service.reverseTransaction(
            ref_num,
            "saman mid",
            "saman mid",
            "saman password"
        )
        return result

    def sep_generate_reservation_number(self):
        return StringUtils.id_generator(size=15)

def payment_process(request):
    order_id = request.session.get('order_id')
    order = get_object_or_404(Order, id=order_id)
    total_cost = order.get_total_cost()

    if request.method == 'POST':
        res_num=str(order.id)
        total =str(total_cost)

        R =PaymentGatewayAdapter()
        tokenrequest=R.sep_request_token(total,res_num, [order.phone, order.first_name])
        # retrieve nonce
        order.paid = True
        order.save()
        order.last_name=tokenrequest.token
        order.save()
        token =tokenrequest.token

        sendtoken =R.sep_verify_transaction(token)

        # create and submit transaction
        result = sendtoken.STATE
        if result== 'OK':
            # mark the order as paid
            order.paid = True
            # store the unique transaction id
            order.braintree_id = sendtoken.CID
            order.save()
            return redirect('payment:done')
        else:
            return redirect('payment:canceled')
    else:
        # generate token
        
        return render(request,
        'payment/process.html',
        {'order': order})
@login_required
def payment_done(request):
    return render(request, 'payment/done.html')
@login_required
def payment_canceled(request):
    return render(request, 'payment/canceled.html')
